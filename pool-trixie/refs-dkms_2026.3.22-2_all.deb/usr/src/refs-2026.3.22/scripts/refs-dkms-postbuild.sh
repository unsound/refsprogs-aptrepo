#!/bin/sh

if [ $# -ne 2 ]; then echo "usage: $0 <base dir> <kernel/arch dir>"; exit 1; fi

cp "${1}/build/Module.symvers" "${1}/${2}/"
